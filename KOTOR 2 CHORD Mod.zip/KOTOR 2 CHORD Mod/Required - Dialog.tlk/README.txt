For this file I advise you open it and apply the changes to your personal dialog.tlk file.

Key changes made in this file:

- Added word Tough for one of the custom difficulty settings
- Added word Suicide for one of the custom difficulty settings
- Added custom numerical values like 2%, 4%, 6% 8% 10%, 12.5% 15% 35%, 37.5%, 40% 45%, 47.5%, 55%, 57.5%, 60%, 65%, 67.5%, 70% for armor / robe custom dmage immunity settings.
- Added numbers like 6, 7, 8, 9, 10 for custom defense values for armor / robes (though these are very lightly used. Most magic here happens in base items.2da


You can use a tool like TalkEd.exe found on deadlystream to open this file and your file. Be sure to add these custom values in the same order as they appear and in the same row numbers in your file.

If you see a blank value for an item, then go back to check your dialog.tlk file to be sure you aren't missing a value.