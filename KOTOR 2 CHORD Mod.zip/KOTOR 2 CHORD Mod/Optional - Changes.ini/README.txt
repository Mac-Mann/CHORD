DO NOT REPLACE / OVERRIDE your existing changes.ini file or your gonna have a bad time.
Instead, add these changes to your existing changes.ini file for best results.
